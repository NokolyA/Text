
-- Создание таблиц
CREATE TABLE Группа (
    ID_группы AUTOINCREMENT PRIMARY KEY,
    [Номер группы] TEXT,
    [Плата за семестр] CURRENCY,
    [Обучение закончено] YESNO
);

CREATE TABLE Студент (
    ID_студента AUTOINCREMENT PRIMARY KEY,
    Фамилия TEXT,
    Имя TEXT,
    Отчество TEXT,
    [Дата рождения] DATE,
    ID_группы LONG,
    FOREIGN KEY (ID_группы) REFERENCES Группа(ID_группы)
);

CREATE TABLE Дисциплина (
    ID_дисциплины AUTOINCREMENT PRIMARY KEY,
    Название TEXT
);

CREATE TABLE Оценка (
    ID_оценки AUTOINCREMENT PRIMARY KEY,
    ID_студента LONG,
    ID_дисциплины LONG,
    Оценка BYTE,
    FOREIGN KEY (ID_студента) REFERENCES Студент(ID_студента),
    FOREIGN KEY (ID_дисциплины) REFERENCES Дисциплина(ID_дисциплины)
);

-- Далее следуют SQL-запросы (из предыдущего ответа)
-- Их можно вставлять в окно SQL в режиме конструктора запросов Access
-- или использовать как основу для ручного ввода.
-- Запросы начинаются с 1 по 9...
-- (см. предыдущий ответ)
